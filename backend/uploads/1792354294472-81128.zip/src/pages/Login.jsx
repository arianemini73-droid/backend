import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { isEmail, matchPassword } from '../helpers/validators'
import { useLocalStorage } from '@uidotdev/usehooks'
function Login() {
  const [errors, setErrors] = useState([])
  
  const navigate = useNavigate()

  const [users, setUsers] = useLocalStorage("users", null);
  const [user, setUser] = useLocalStorage("user", null);

  const handleLogin = event => {
    event.preventDefault()
    
    const data = event.target.elements 
    
    const email = data.email.value
    const password = data.password.value
    
    if(!isEmail(email)) {
      setErrors(errors => [`Email: <span className="font-bold">${email}</span> is not valid`])
      return;
    }
    
    const fetchUser = users.filter(u => u.email === email && u.password === password)

    if(fetchUser?.length > 0) {
      setUser(fetchUser[0])
      navigate('/dashboard')
    } else {
      setErrors(errors => [`Invalid credentials`])
      return;
    }
  }

  return (
  <section className="py-25">
        <div className="container mx-auto">

            <h2 className="text-2xl font-bold text-gray-700 capitalize dark:text-white">Login</h2>

            { (errors && errors?.length > 0) &&
              <div className="flex my-12 w-full overflow-hidden bg-white rounded-lg shadow-md dark:bg-gray-800">
                  <div class="flex items-center justify-center w-12 bg-yellow-400">
                      <svg class="w-6 h-6 text-white fill-current" viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
                          <path d="M20 3.33331C10.8 3.33331 3.33337 10.8 3.33337 20C3.33337 29.2 10.8 36.6666 20 36.6666C29.2 36.6666 36.6667 29.2 36.6667 20C36.6667 10.8 29.2 3.33331 20 3.33331ZM21.6667 28.3333H18.3334V25H21.6667V28.3333ZM21.6667 21.6666H18.3334V11.6666H21.6667V21.6666Z" />
                      </svg>
                  </div>

                  <div className="px-4 py-2 -mx-3">
                      <div class="mx-3">
                          <span class="font-semibold text-yellow-400 dark:text-yellow-300">Warning</span>
                          {
                            errors?.map(error => <p class="text-sm text-gray-600 dark:text-gray-200" dangerouslySetInnerHTML={{ __html: error }} />)
                          }
                      </div>
                  </div>
              </div>
            }

            <form className="mt-12" onSubmit={handleLogin}>
                <div className="grid grid-cols-1 gap-6 mt-4 sm:grid-cols-2">
                    <div>
                        <label className="text-gray-700 dark:text-gray-200" htmlFor="email">Email Address</label>
                        <input id="email" name="email" type="text" className="block w-full px-4 py-2 mt-2 text-gray-700 bg-white border border-gray-200 rounded-md dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600 focus:border-blue-400 focus:ring-blue-300 focus:ring-opacity-40 dark:focus:border-blue-300 focus:outline-none focus:ring" />
                    </div>

                    <div>
                        <label className="text-gray-700 dark:text-gray-200" htmlFor="password">Password</label>
                        <input id="password" name="password" type="password" className="block w-full px-4 py-2 mt-2 text-gray-700 bg-white border border-gray-200 rounded-md dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600 focus:border-blue-400 focus:ring-blue-300 focus:ring-opacity-40 dark:focus:border-blue-300 focus:outline-none focus:ring" />
                    </div>
                </div>

                <div className="flex justify-end items-center gap-4 mt-12">
                    <button className="px-8 py-2.5 leading-5 text-white transition-colors duration-300 transform bg-gray-700 rounded-md hover:bg-gray-600 focus:outline-none focus:bg-gray-600">Login</button>
                    <Link to="/register" className="underline text-blue-600">Create account</Link>
                </div>
            </form>

        </div>
    </section>
  )
}

export default Login