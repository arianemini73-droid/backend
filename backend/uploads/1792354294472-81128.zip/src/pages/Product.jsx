import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { Link } from 'react-router-dom'
import { useLocalStorage } from '@uidotdev/usehooks'

function Product() {
  const [cart, setCart] = useLocalStorage("cart", null);

  const [qty, setQty] = useState(1)

  const {id} = useParams()
  const navigate = useNavigate()

  const [product, setProduct] = useState()

  useEffect(() => {
    axios.get(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${id}`)
    .then(response => {
      if(response?.data?.meals === null) navigate('/')
      setProduct(response?.data?.meals[0])
    })
  }, [])

  const handleAddToCart = () => {
    const item = {
      ...product,
      qty
    }

    if(qty > 0) {
      if(cart?.length > 0) {
        if(cart?.filter(product => product.idMeal === item.idMeal)?.length > 0) {
          setCart([...cart.map(product => (product.idMeal === item.idMeal) ? {...product, qty: product.qty + qty} : product)])
        } else {
          setCart([...cart, item])
        }
      } else {
        setCart([item])
      }

      alert(`${product?.strMeal} was added to cart`)
    } else  {
      alert(`Qty must be at least 1`)
    }
  }

  return (
    <>
    {
      product && <section className="bg-gray-50 py-25">
        <div className="container mx-auto">
            <div className="flex gap-12 my-12" id="product">
                <img src={product.strMealThumb} alt={product.strMeal} />
                <div className="flex flex-col gap-8">
                    <h2 id="title" className="text-3xl font-bold text-gray-900">{product.strMeal}</h2>
                    <p id="area">{product.strArea}</p>
                    <p id="country">{product.strCountry}</p>
                    <p id="instructions">{product.strInstructions}</p>
                    {
                      product?.strSource !== null && <p>
                        Source: 
                        <Link to={product.strSource} className="underline text-blue-500">{product.strSource}</Link>
                      </p>
                    }

                    <form id="add-to-cart-form">
                        <div className="flex items-center gap-4">
                            <input onChange={event => setQty(parseInt(event.target.value))} id="qty" name="qty" type="number" value={qty} min="1" max="10" className="block w-50 px-4 py-2 text-gray-700 bg-white border border-gray-200 rounded-md dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600 focus:border-blue-400 focus:ring-blue-300 focus:ring-opacity-40 dark:focus:border-blue-300 focus:outline-none focus:ring" />
                            <button onClick={handleAddToCart} type="submit" className="px-8 py-2.5 leading-5 text-white transition-colors duration-300 transform bg-gray-700 rounded-md hover:bg-gray-600 focus:outline-none focus:bg-gray-600">Add to cart</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    }
    </>
  )
}

export default Product