import React, { useRef, useState } from 'react'
import ReactMarkdown from "react-markdown";
import axios from 'axios';

function Chatbot() {
  const [prompt, setPrompt] = useState('')
  const [output, setOutput] = useState()

  const msg = useRef()

  const API_KEY = import.meta.env.VITE_OPEN_AI_API_KEY;

  console.log(API_KEY)

  const handleOpenAICall = event => {
    const current_prompt = event.target.value

    switch(event.keyCode) {
      case 13: 
        setOutput('')

        if(current_prompt?.length < 5) {
          alert('Prompt must be at least 5 characters!')
          return;
        }

        msg.current.style.display = "block"
        msg.current.textContent = "Please wait! AI is generating your receipe 🐸"

        const api_prompt = `Generate receipe for ${current_prompt} including ingridients calories table - don't replay if question is not related to food receipes`
        
        axios.post("https://api.openai.com/v1/responses",
          {
            model: "gpt-5.5",
            input: api_prompt
          },
          {
            headers: {
              Authorization: `Bearer ${API_KEY}`,
              "Content-Type": "application/json"
          }
        }).then(response => {
          setOutput(response.data.output[1].content[0].text)
        
          msg.current.textContent = ""
          msg.current.style.display = "none"
        })
      break
    }
  }
  
  return (
  <section className="py-25">
        <div className="container mx-auto">

            <h2 className="text-2xl font-bold text-gray-700 capitalize dark:text-white">Generate Receipe</h2>

            <input type="text" onKeyUp={handleOpenAICall} onChange={event => setPrompt(event.target.value)} className="block w-full px-4 py-2 mt-2 text-gray-700 bg-white border border-gray-200 rounded-md dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600 focus:border-blue-400 focus:ring-blue-300 focus:ring-opacity-40 dark:focus:border-blue-300 focus:outline-none focus:ring mb-12" value={prompt} />

            <p ref={msg}></p>

            <ReactMarkdown>{output}</ReactMarkdown>
        </div>
    </section>
  )
}

export default Chatbot