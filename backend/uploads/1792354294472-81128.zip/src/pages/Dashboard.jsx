import React from 'react'
import { useLocalStorage } from '@uidotdev/usehooks';

function Dashboard() {
  const [user, setUser] = useLocalStorage("user", null);
  const [orders, setOrders] = useLocalStorage("orders", null);

  return (
    <section className="py-25">
        <div className="container mx-auto">
            <h2 className="text-2xl font-bold text-gray-700 capitalize dark:text-white">Orders</h2>
            {
              orders?.filter(order => order.user === user.email) ? <table className="table w-full mt-12">
              <thead>
                <tr>
                  <th className="border border-gray-300 px-4 py-2">Fullname</th>
                  <th className="border border-gray-300 px-4 py-2">Phone</th>
                  <th className="border border-gray-300 px-4 py-2">Email</th>
                  <th className="border border-gray-300 px-4 py-2">Delivery Address</th>
                  <th className="border border-gray-300 px-4 py-2">Items</th>
                </tr>
              </thead>
              <tbody>
                {
                  orders?.filter(order => order.user === user.email).map((order, index) => <tr key={index}>
                    <td className="border border-gray-300 px-4 py-2">{user.fullname}</td>
                    <td className="border border-gray-300 px-4 py-2">{order.phone}</td>
                    <td className="border border-gray-300 px-4 py-2">{order.email}</td>
                    <td className="border border-gray-300 px-4 py-2">{order.address}</td>
                    <td className="border border-gray-300 px-4 py-2">
                      {
                        order?.items?.map(item => <p key={item.idMeal}>{item.strMeal}</p>)
                      }
                    </td>
                  </tr>)
                }
              </tbody>
            </table> : <p>0 orders</p>
            }
        </div>
    </section>
  )
}

export default Dashboard