import axios from 'axios'
import React, { useEffect, useRef, useState } from 'react'
import { useParams } from 'react-router-dom'
import Product from '../components/Product'

function Products() {
  const [products, setProducts] = useState()

  const {category} = useParams()

  useEffect(() => {
    axios.get(`https://www.themealdb.com/api/json/v1/1/filter.php?c=${category}`)
    .then(response => setProducts(response?.data?.meals))
  }, [])

  return (
    <div className='container mx-auto my-12'>
      <h2 id="title" className="text-3xl font-bold text-gray-900">Category: <i>{category}</i> &gt; Products</h2>
      <div className="grid grid-cols-4 gap-3 mt-12">
          {
            products && products?.map(product => <Product key={product.idMeal} {...product} />)
          }
      </div>
    </div>
  )
}

export default Products