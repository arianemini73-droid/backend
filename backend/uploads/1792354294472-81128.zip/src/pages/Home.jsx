import React, { useEffect, useRef, useState } from 'react'
import app from "../assets/img/app.png"
import gallery from "../assets/img/gallery.png"
import axios from 'axios'
import Card from '../components/Card'
import { Link } from 'react-router-dom'

function Home() {

  const [categories, setCategories] = useState()
  const [index, setIndex] = useState(0)
  const [category, setCategory] = useState()

  useEffect(() => {
    axios.get(`https://www.themealdb.com/api/json/v1/1/categories.php`)
    .then(response => setCategories(response?.data?.categories))
  }, [])


  useEffect(() => {
    if(categories) {
      setCategory(categories[0]?.strCategory)
    }

    const updateIndex = setInterval(() => {
      if(index < categories?.length) {
        setIndex(index => index+=1)
      } else {
        setIndex(0)
      }
    }, 3000)

    return () => {
      clearInterval(updateIndex)
    }
  }, [categories])

  useEffect(() => {
    if(categories) {
      setCategory(categories[index]?.strCategory)
    }
  }, [index])

  return (
    <>
    <div className="container mx-auto">
      <main className="bg-white">
          <div className="container mx-auto">
              <div className="h-110 flex justify-between">
                  <img src={app} alt="App Screenshot" />
                  <div id="content" className="w-[60%] flex flex-col justify-center gap-8">
                      <h1 className="text-6xl font-bold text-orange-600">
                        Are you hungry? 
                        <span className="text-gray-900 ms-4">
                          {category && category}
                        </span>
                      </h1>
                      <p className="text-xl text-orange-900 text-justify">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Enim voluptates sequi architecto repellat voluptatem repudiandae id cum ipsam placeat perspiciatis porro totam veritatis aperiam qui sunt animi modi, rem culpa!</p>
                  </div>
              </div>
          </div>
      </main>

      <section className="bg-gray-50 py-25">
          <h2 className="text-5xl font-bold text-gray-900 text-center">
            Explore our delicious food
          </h2>
        
          <div className="grid grid-cols-4 gap-6 my-12">
            {
              categories && categories?.slice(0, 8)?.map(category => <Card key={category?.idCategory} {...category} />)
            }
          </div>

          <div className="flex justify-center">
            <Link to="/categories" className="px-6 py-2 font-medium tracking-wide text-white capitalize transition-colors duration-300 transform bg-orange-600 rounded-lg hover:bg-orange-500 focus:outline-none focus:ring focus:ring-orange-300 focus:ring-opacity-80 flex items-center gap-4">
              Categories 
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640" className="w-5 fill-white">
                <path d="M598.6 342.6C611.1 330.1 611.1 309.8 598.6 297.3L470.6 169.3C458.1 156.8 437.8 156.8 425.3 169.3C412.8 181.8 412.8 202.1 425.3 214.6L498.7 288L64 288C46.3 288 32 302.3 32 320C32 337.7 46.3 352 64 352L498.7 352L425.3 425.4C412.8 437.9 412.8 458.2 425.3 470.7C437.8 483.2 458.1 483.2 470.6 470.7L598.6 342.7z"></path>
              </svg>
            </Link>
          </div>
      </section>

      <section className="py-25">
          <p className="text-gray-900 text-3xl text-center">
            FOODYS is a Helsinki-based technology company with a mission to bring joy, simplicity and earnings to the neighborhoods of the world. FOODYS develops a local commerce platform that connects people looking to order food, groceries, and other goods with people interested in selling and delivering them. Wolt was founded in 2014 and joined forces with DoorDash (NASDAQ: DASH) in 2022. Altogether, DoorDash operates in more than 40 countries today. 
          </p>
          <img src={gallery} className="mt-12 mx-auto" />
      </section>
    </div>
    <section className="w-full">
        <iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d11983.912873036268!2d19.790474622517927!3d41.331087003673765!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1stirana%20center!5e0!3m2!1sen!2smk!4v1783964558334!5m2!1sen!2smk" width="100%" height="450" style={{border: 0}} allowFullScreen="" loading="lazy" referrerPolicy="strict-origin-when-cross-origin"></iframe>
    </section>
    </>
  )
}

export default Home