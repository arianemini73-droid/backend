import React from 'react'
import { useLocalStorage } from '@uidotdev/usehooks';
import { roundPrice } from '../helpers/formaters';
import {isEmail, hasRKSFormat} from "../helpers/validators"
import { useNavigate } from 'react-router-dom';

function Cart() {
  const [cart, setCart] = useLocalStorage("cart", null);
  const [user, setUser] = useLocalStorage("user", null);
  const [orders, setOrders] = useLocalStorage("orders", null);

  const navigate = useNavigate()

  const handleDec = idMeal => {
    setCart([...cart.map(item => (item.idMeal === idMeal) ? {...item, qty: item.qty - 1} : item).filter(item => item.qty > 0)])
  }

  const handleInc = idMeal => {
    setCart([...cart.map(item => (item.idMeal === idMeal) ? {...item, qty: item.qty + 1} : item)])
  }

  const handleCheckout = event => {
    event.preventDefault()

    const data = event.target.elements

    const phone = data.phone.value
    const email = data.email.value
    const address = data.address.value

    if(!hasRKSFormat(phone)) {
      alert(`Please enter valid phone number`)
      return;
    }

    if(!isEmail(email)) {
      alert(`Please enter valid email address`)
      return;
    }
  
    const order = {
      items: cart,
      user: user?.email,
      phone,
      email,
      address
    }

    if(orders?.length > 0) {
      setOrders([...orders, order])
    } else {
      setOrders([order])
    }

    alert(`Order was placed successfully`)

    setCart([])

    navigate('/dashboard')
  }

  return (
  <section className="py-25">
        <div className="container mx-auto">
            <h2 className="text-2xl font-bold text-gray-700 capitalize dark:text-white">Cart ({cart?.length})</h2>
            {
              cart && <table className="table w-full mt-12">
              <thead>
                <tr>
                  <th className="border border-gray-300 px-4 py-2">Product</th>
                  <th className="border border-gray-300 px-4 py-2">Price (EUR)</th>
                  <th className="border border-gray-300 px-4 py-2">Qty</th>
                  <th className="border border-gray-300 px-4 py-2">Subtotal (EUR)</th>
                </tr>
              </thead>
              <tbody>
                {
                  cart.map(item => <tr key={item.idMeal}>
                    <td className="border border-gray-300 px-4 py-2">{item.strMeal}</td>
                    <td className="border border-gray-300 px-4 py-2 text-right">{roundPrice(item.idMeal / 10000)}</td>
                    <td className="border border-gray-300 px-4 py-2 text-center space-x-4">
                      <button onClick={() => handleDec(item.idMeal)} className='border border-gray-300 rounded-md hover:bg-gray-200 cursor-pointer px-2'>-</button>
                      <span>{item.qty}</span>
                      <button onClick={() => handleInc(item.idMeal)} className='border border-gray-300 rounded-md hover:bg-gray-200 cursor-pointer px-2'>+</button>
                    </td>
                    <td className="border border-gray-300 px-4 py-2 text-right">{roundPrice((item.idMeal / 10000) * item.qty)}</td>
                  </tr>)
                }
              </tbody>
              <tfoot>
                <tr>
                  <td className="border border-gray-300 px-4 py-2" colSpan={3}></td>
                  <td className="border border-gray-300 px-4 py-2 text-right font-bold">
                    {cart && roundPrice(cart.reduce((sum, item) => (sum + ((item.idMeal / 10000) * item.qty)), 0.00))}
                  </td>
                </tr>
              </tfoot>
            </table>
            }
        </div>
        {
          (cart && cart?.length > 0) && (user !== null) && <div id="checkout" className="container mx-auto bg-gray-50 py-4 px-6 mt-12">
            <h2 className="text-2xl font-bold text-gray-700 capitalize dark:text-white">Checkout</h2>
            <form id="checkout-form" className="mt-12" onSubmit={handleCheckout}>
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                    <div>
                        <label className="text-gray-700 dark:text-gray-200" htmlFor="phone">Phone</label>
                        <input id="phone" name="phone" type="text" className="block w-full px-4 py-2 mt-2 text-gray-700 bg-white border border-gray-200 rounded-md dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600 focus:border-blue-400 focus:ring-blue-300 focus:ring-opacity-40 dark:focus:border-blue-300 focus:outline-none focus:ring" placeholder="ex. 044690100"/>
                    </div>

                    <div>
                        <label className="text-gray-700 dark:text-gray-200" htmlFor="email">Email</label>
                        <input id="email" name="email" type="text" className="block w-full px-4 py-2 mt-2 text-gray-700 bg-white border border-gray-200 rounded-md dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600 focus:border-blue-400 focus:ring-blue-300 focus:ring-opacity-40 dark:focus:border-blue-300 focus:outline-none focus:ring"/>
                    </div>

                    <div>
                        <label className="text-gray-700 dark:text-gray-200" htmlFor="address">Address</label>
                        <input id="address" name="address" type="text" className="block w-full px-4 py-2 mt-2 text-gray-700 bg-white border border-gray-200 rounded-md dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600 focus:border-blue-400 focus:ring-blue-300 focus:ring-opacity-40 dark:focus:border-blue-300 focus:outline-none focus:ring"/>
                    </div>
                </div>

                <div className="flex justify-end items-center gap-4 mt-6">
                    <button className="px-8 py-2.5 leading-5 text-white transition-colors duration-300 transform bg-gray-700 rounded-md hover:bg-gray-600 focus:outline-none focus:bg-gray-600">Checkout</button>
                </div>
            </form>
        </div>
        }
    </section>
  )
}

export default Cart