import React, { useEffect, useRef, useState } from 'react'
import axios from 'axios'
import Card from '../components/Card'
import { Link } from 'react-router-dom'

function Categories() {

  const [categories, setCategories] = useState()

  useEffect(() => {
    axios.get(`https://www.themealdb.com/api/json/v1/1/categories.php`)
    .then(response => setCategories(response?.data?.categories))
  }, [])


  return (
    <div className="container mx-auto">
        <div className="grid grid-cols-4 gap-6 my-12">
          {
            categories && categories?.map(category => <Card key={category?.idCategory} {...category} />)
          }
        </div>
    </div>
  )
}

export default Categories