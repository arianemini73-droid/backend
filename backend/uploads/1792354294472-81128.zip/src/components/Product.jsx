import React from 'react'
import { Link } from 'react-router-dom'

function Product({idMeal, strMeal, strMealThumb, strCountry}) {
  return (
    <div className="border border-gray-300 rounded-md shadow p-2 space-y-3">
        <img src={strMealThumb} alt="" />
        <p>{strCountry}</p>
        <Link to={`/product/${idMeal}`} className="text-2xl text-gray-900 font-bold">{strMeal}</Link>
    </div>
  )
}

export default Product