import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import logo from "../assets/img/logo.png"
import { useLocalStorage } from '@uidotdev/usehooks';

function Header() {
    const [user, setUser] = useLocalStorage("user", null);

    const navigate = useNavigate()

    const handleLogout = () => {
        if(confirm('Are you sure?')) {
            setUser(null)
            navigate('/login')
        }
    }

    return (
        <header>
            <nav className="relative bg-white shadow dark:bg-gray-800">
                <div className="container py-4 mx-auto md:flex md:justify-between md:items-center">
                    <div className="flex items-center justify-between">
                        <Link to="/">
                            <img className="w-auto h-6 sm:h-7" src={logo} alt="FOODYS" />
                        </Link>
                    </div>
                    <div className="absolute inset-x-0 z-20 w-full px-6 py-4 transition-all duration-300 ease-in-out bg-white dark:bg-gray-800 md:mt-0 md:p-0 md:top-0 md:relative md:bg-transparent md:w-auto md:opacity-100 md:translate-x-0 md:flex md:items-center">
                        <div className="flex flex-col md:flex-row gap-6">
                            <Link className="my-2 text-gray-700 transition-colors duration-300 transform dark:text-gray-200 hover:text-blue-500 dark:hover:text-blue-400 md:my-0" to="/">Home</Link>
                            <Link className="my-2 text-gray-700 transition-colors duration-300 transform dark:text-gray-200 hover:text-blue-500 dark:hover:text-blue-400 md:my-0" to="/categories">Categories</Link>
                            <Link className="my-2 text-gray-700 transition-colors duration-300 transform dark:text-gray-200 hover:text-blue-500 dark:hover:text-blue-400 md:my-0" to="/chatbot">Chat bot</Link>
                            <Link className="my-2 text-gray-700 transition-colors duration-300 transform dark:text-gray-200 hover:text-blue-500 dark:hover:text-blue-400 md:my-0" to="/cart">Cart</Link>
                            {
                                user === null ? <>
                                    <Link className="my-2 text-gray-700 transition-colors duration-300 transform dark:text-gray-200 hover:text-blue-500 dark:hover:text-blue-400 md:my-0" to="/register">Register</Link>
                                    <Link className="my-2 text-gray-700 transition-colors duration-300 transform dark:text-gray-200 hover:text-blue-500 dark:hover:text-blue-400 md:my-0" to="/login">Login</Link>
                                </> : <>
                                    <Link className="my-2 text-gray-700 transition-colors duration-300 transform dark:text-gray-200 hover:text-blue-500 dark:hover:text-blue-400 md:my-0" to="/dashboard">Dashboard</Link>
                                    <button className="my-2 text-gray-700 transition-colors duration-300 transform dark:text-gray-200 hover:text-blue-500 dark:hover:text-blue-400 md:my-0" onClick={handleLogout}>Logout</button>
                                </>
                            }
                        </div>
                    </div>
                </div>
            </nav>
        </header>
    )
}

export default Header