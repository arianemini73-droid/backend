import React from 'react'
import { Link } from 'react-router-dom'

function Card({strCategory, strCategoryThumb}) {
  return (
    <div className="border border-gray-300 rounded-md shadow p-4">
        <img src={strCategoryThumb} alt={strCategory} />
        <Link to={`/categories/${strCategory}/products`} className="text-2xl text-gray-900 font-bold">
            {strCategory}
        </Link>
    </div>
  )
}

export default Card