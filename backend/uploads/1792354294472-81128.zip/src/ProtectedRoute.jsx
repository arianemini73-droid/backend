import React from 'react'
import { useLocalStorage } from '@uidotdev/usehooks'
import { Outlet, Navigate } from "react-router";

function ProtectedRoute() {
  const [user, setUser] = useLocalStorage("user", null);

  return (user !== null) ? <Outlet /> : <Navigate to="/login" replace />;
}

export default ProtectedRoute