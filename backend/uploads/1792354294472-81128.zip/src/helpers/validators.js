export function isEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return regex.test(email)
}

export function hasRKSFormat(phone) {
    const regex = /^(044|045)\d{6}$/
    return regex.test(phone)
}

export function matchPassword(password, passwordConfirmation){
    return password === passwordConfirmation
}