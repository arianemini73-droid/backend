export function roundPrice(price) {
    return price.toFixed(2)
}