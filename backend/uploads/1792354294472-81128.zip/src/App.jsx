import { BrowserRouter, Routes, Route } from "react-router-dom"
import Home from "./pages/Home"
import Categories from "./pages/Categories"
import Products from "./pages/Products"
import Product from "./pages/Product"
import Chatbot from "./pages/Chatbot"
import Cart from "./pages/Cart"
import Register from "./pages/Register"
import Login from "./pages/Login"
import Dashboard from "./pages/Dashboard"


import Header from "./components/Header"
import Footer from "./components/Footer"


import ProtectedRoute from "./ProtectedRoute"

function App() {

  return (
    <BrowserRouter>
      <Header />
      <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/categories" element={<Categories />} />
          <Route path="/categories/:category/products" element={<Products />} />
          <Route path="/product/:id" element={<Product />} />
          <Route path="/chatbot" element={<Chatbot />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          <Route element={<ProtectedRoute />}>
            <Route path="/dashboard" element={<Dashboard />} />
          </Route>
      </Routes>
      <Footer />
    </BrowserRouter>
  )
}

export default App
